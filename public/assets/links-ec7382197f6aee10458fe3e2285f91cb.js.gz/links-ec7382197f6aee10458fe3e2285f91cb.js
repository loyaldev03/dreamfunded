function invest() {
	window.location = "/companies"
}

function profile() {
	window.location = "/users/profile"
}

function signOut() {
	window.location = "/users/signout"
}

function signUp() {
	window.location = "/users/new";
}

function about() {
	window.location = "/home/about";
}

function team() {
	window.location = "/home/team";
}

function faq() {
	window.location = "/home/faq";
}

function contact() {
	window.location = "/contact";
}

function funding() {
	window.location = "/companies/new";
}

function exchange() {
	window.location = "http://exchange.dreamfunded.com/";
}

function news() {
	window.location = "/news"
}

function whyInv() {
	window.location = "/home/why";
}

function signIn() {
	window.location = "/users/login";
}

function home() {
	window.location = "/home";
}

function portfolio() {
	window.location = "/users/portfolio";
}

function admin() {
	window.location = "/users/write";
}

function legal() {
	window.location = "/home/legal";
}
;
